require('coffee-script');
require('./lib/server.coffee');